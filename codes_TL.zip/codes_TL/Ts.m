function f=Ts(t)
                Tmin = 0;
                Tmax = 40;
                if (t<(Tmin + 273.15)) % t:unit:K, Tmin:℃
                    f = 0;
                elseif (t>(Tmax + 273.15))
                    f = 0;
                else
                    f = (t-273.15-Tmin)*(t-273.15-Tmax)/((t-273.15-Tmin)*(t-273.15-Tmax)-(t-273.15-Topt)*(t-273.15-Topt));
                end