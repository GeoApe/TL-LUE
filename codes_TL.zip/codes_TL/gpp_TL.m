%% the revised TL-LUE model (in " A global 0.05-degree dataset for gross primary production of sunlit and shaded vegetation canopies from 1992 to 2020")
 %% constants
e=2.7143;
pi=3.1415926;
BeginYear=1992;
EndYear=2020;
rows=3600;
columns=7200;

%% calculating
for year=BeginYear:EndYear
  
    for jday=1:365
     %% input CO2 concentration, meteorology data,LAI,landcover and et al. (Ca,t, vpd, LAI, LandCover,PAR,costha_m)
        
        for i=1:rows
  
            for j=1:columns
             %% input parameters  by different vegetation types
             [omega,alpha,Topt,eps_sun,eps_shade] = parameters_TL(LandCover);
                
              %% separate sunlit/shaded leaves
                [LAIsun,LAIshade]=LAIsep(omega,lai,costha_m);
                [PARdif_under,C,PARdif,PARdir]=PARsep();
                
                [APARsun,APARshade]=APARsep(costha_m,LAIsun,LAIshade,lai,PARdif_under,C,PARdif,PARdir);
                
               %% temperatere scalar 
                f=Ts(t(i,j));
                
                %% CO2 scalar
                c=Cs(t(i,j),vpd(i,j),Ca);
                
                %% VPD scalar
                g=Ws(vpd(i,j));
                
                %% calculate GPPs
                GPP_sun(i,j) = eps_sun*APARsun*f*g*c;
                GPP_shade(i,j) = eps_shade*APARshade*f*g*c;
                GPP(i,j) = GPP_sun(i,j) + GPP_shade(i,j);
                
            end
        end
     %% output GPP products(annual, monthly, 8-day) .For example, the following:
        if (jday==(floor(jday/8)*8)||jday==365)
            day=floor((jday-1)/8)*8+1;
            geotiffwrite(outputPath,int16(GPP_8day*100),R);
            geotiffwrite(outputPath,int16(SunGPP_8day*100),R);
            geotiffwrite(outputPath,int16(ShadeGPP_8day*100),R);         
        end
   end
end

