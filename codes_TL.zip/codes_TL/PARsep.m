function [PARdif_under,C,PARdif,PARdir]=PARsep(omega,PAR,lai,costha_m)

    R = PAR / (1367*0.43*costha_m);
        PARdif = PAR * (0.7527 + 3.8453*R - 16.316*R*R + 18.962*R*R*R - 7.0802*R*R*R*R);
        PARdir = PAR - PARdif;
    cos_szaa = 0.537 + 0.025*lai;
        PARdif_under = PARdif*exp(-0.5*omega*lai / cos_szaa);
        C = 0.07*omega*PARdir*(1.1 - 0.1*lai)*exp(-costha_m);
        